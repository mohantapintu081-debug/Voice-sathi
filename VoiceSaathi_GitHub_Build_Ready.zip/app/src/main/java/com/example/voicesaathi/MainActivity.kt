package com.example.voicesaathi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val req = 500

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(0xFFF4F7FB.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Voice Saathi"; textSize = 30f; gravity = Gravity.CENTER
            setTextColor(0xFF15324B.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Voice commands for your approved apps"; textSize = 16f; gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        })
        status = TextView(this).apply {
            text = "Tap Start listening. This version uses on-device speech recognition only and does not request internet access. Android 12+ and an installed offline Hindi speech pack are required."
            textSize = 16f; setPadding(16, 18, 16, 18); setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "Start background listening"
            setOnClickListener { requestAndStart() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        root.addView(Button(this).apply {
            text = "Stop listening"
            setOnClickListener {
                stopService(Intent(this@MainActivity, VoiceListeningService::class.java))
                status.text = "Listening stopped."
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(TextView(this).apply {
            text = "Allowed apps: Phone Book/Dialer, Contacts, Gallery, Camera, Calendar, YouTube, Facebook, WhatsApp, Instagram and Google Chrome.\n\nTry saying: “Hi Sabita” — the app replies “हाँ, बताइए? मैं सुन रही हूँ।” Then say “WhatsApp खोलो”. You can also say “Hi Sabita, WhatsApp खोलो” in one phrase. Other examples: “हे सबिता, YouTube खोलो”, “WhatsApp खोलो”, “Facebook खोलो”, “Camera खोलो”, “Contacts खोलो”.\n\nOffline mode: needs Android 12+ and an offline Hindi speech-recognition model installed on your phone. If on-device recognition is unavailable, it stops instead of switching to an online recognizer. Android/Samsung may still stop background listening due to battery restrictions. Use the ongoing notification to stop it."
            textSize = 13f; setPadding(4, 18, 4, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), req)
            return
        }
        val intent = Intent(this, VoiceListeningService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            status.text = "Offline listening requested. Say “Hi Sabita” and wait for its spoken reply, then give a command for one of your approved apps. If the offline Hindi model is missing, the service will stop and show a message."
        } catch (e: Exception) {
            status.text = "Could not start listening. Open the app again and check microphone permission."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == req && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) requestAndStart()
        else status.text = "Microphone permission is required for voice commands."
    }
}
