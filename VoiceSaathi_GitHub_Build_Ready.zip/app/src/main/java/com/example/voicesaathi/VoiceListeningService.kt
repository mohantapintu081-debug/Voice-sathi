package com.example.voicesaathi

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.core.app.NotificationCompat
import java.util.Locale

class VoiceListeningService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var torchOn = false
    private var restarting = false
    private var awaitingCommand = false
    private val channelId = "voice_saathi_listening"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(42, buildNotification())
        textToSpeech = TextToSpeech(applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val hindi = textToSpeech?.setLanguage(Locale("hi", "IN"))
                if (hindi == TextToSpeech.LANG_MISSING_DATA || hindi == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.setLanguage(Locale.US)
                }
            }
        }
        textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { scheduleRestart() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { scheduleRestart() }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        startRecognition()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Voice Saathi listening", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Shows when Voice Saathi is using the microphone"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, VoiceListeningService::class.java).apply { action = "STOP" }
        val stopPending = PendingIntent.getService(this, 43, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val openPending = PendingIntent.getActivity(this, 44, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Voice Saathi — offline listening")
            .setContentText("On-device speech recognition only. Tap Stop to disable.")
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_media_pause, "Stop listening", stopPending)
            .build()
    }

    private fun startRecognition() {
        // Strict offline mode: never fall back to the regular recognizer, which may use a network service.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            Toast.makeText(this, "Offline voice recognition needs Android 12 or newer.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            Toast.makeText(this, "On-device speech recognition is unavailable. Install an offline Hindi speech pack in your phone settings.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) { scheduleRestart() }
                    override fun onResults(results: Bundle?) {
                        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        val waitingForSpokenReply = handleCommand(heard.lowercase(Locale.ROOT))
                        if (!waitingForSpokenReply) scheduleRestart()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    private fun scheduleRestart() {
        if (restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecognition()
        }, 900)
    }

    private fun handleCommand(command: String): Boolean {
        val wakePhrases = listOf("hey saathi", "हे साथी", "हे सारथी", "hey sabita", "hi sabita", "हे सबिता", "हे सविता", "हाय सबिता")
        val wake = wakePhrases.firstOrNull { command.contains(it) }

        // Support both “Hey Saathi, open YouTube” and two separate utterances:
        // “Hey Saathi” ... then “open YouTube”.
        val actionText = if (wake != null) {
            awaitingCommand = true
            command.substringAfter(wake).trim().trim(',', '.', ' ')
        } else if (awaitingCommand) {
            awaitingCommand = false
            command.trim()
        } else {
            return false
        }

        if (actionText.isBlank()) {
            // Wake phrase only: answer aloud, then listen for the next command.
            awaitingCommand = true
            if (ttsReady && textToSpeech != null) {
                textToSpeech?.speak("हाँ, बताइए? मैं सुन रही हूँ।", TextToSpeech.QUEUE_FLUSH, null, "wake_reply")
                return true
            }
            return false
        }

        awaitingCommand = false
        // Strict allowlist: only the ten user-approved app categories are handled here.
        // No generic package name or arbitrary Settings/Torch command is accepted.
        when {
            actionText.contains("whatsapp") || actionText.contains("व्हाट्सऐप") -> openAllowedApp("com.whatsapp")
            actionText.contains("youtube") || actionText.contains("यूट्यूब") -> openAllowedApp("com.google.android.youtube")
            actionText.contains("chrome") || actionText.contains("google chrome") || actionText.contains("क्रोम") -> openAllowedApp("com.android.chrome")
            actionText.contains("facebook") || actionText.contains("फेसबुक") -> openAllowedApp("com.facebook.katana")
            actionText.contains("instagram") || actionText.contains("इंस्टाग्राम") -> openAllowedApp("com.instagram.android")
            actionText.contains("gallery") || actionText.contains("गैलरी") || actionText.contains("photos") -> openGallery()
            actionText.contains("camera") || actionText.contains("कैमरा") -> openIntent(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            actionText.contains("calendar") || actionText.contains("कैलेंडर") -> openCalendar()
            actionText.contains("contacts") || actionText.contains("contact") || actionText.contains("संपर्क") -> openContacts()
            actionText.contains("phone book") || actionText.contains("phonebook") || actionText.contains("dialer") || actionText.contains("फोन") || actionText.contains("कॉल") -> openDialer()
            actionText.contains("stop listening") || actionText.contains("सुनना बंद") || actionText.contains("सो जाओ") -> stopSelf()
            else -> Toast.makeText(this, "यह कमांड अनुमति वाली ऐप्स में नहीं है।", Toast.LENGTH_SHORT).show()
        }
        return false
    }

    private fun openAllowedApp(packageName: String) {
        val allowedPackages = setOf(
            "com.whatsapp", "com.google.android.youtube", "com.android.chrome",
            "com.facebook.katana", "com.instagram.android"
        )
        if (packageName !in allowedPackages) return
        packageManager.getLaunchIntentForPackage(packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(it) } catch (_: Exception) {
                Toast.makeText(this, "यह ऐप इस फ़ोन पर उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show()
            }
        } ?: Toast.makeText(this, "यह ऐप इस फ़ोन पर इंस्टॉल नहीं है।", Toast.LENGTH_SHORT).show()
    }

    private fun openGallery() {
        val intent = packageManager.getLaunchIntentForPackage("com.sec.android.gallery3d")
            ?: packageManager.getLaunchIntentForPackage("com.google.android.apps.photos")
        if (intent != null) openIntent(intent)
        else Toast.makeText(this, "Gallery ऐप नहीं मिली।", Toast.LENGTH_SHORT).show()
    }

    private fun openContacts() = openIntent(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))

    private fun openDialer() = openIntent(Intent(Intent.ACTION_DIAL))

    private fun openCalendar() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)
        openIntent(intent)
    }

    private fun openIntent(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) {
            Toast.makeText(this, "अनुमति वाली ऐप नहीं खुल सकी।", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setTorch(enabled: Boolean) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            manager.setTorchMode(id, enabled)
            torchOn = enabled
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
