# Voice Saathi Offline Voice Commands (starter)

This is an Android Studio/Kotlin starter project, not a prebuilt APK.

## Included
- Explicit Start/Stop background listening controls
- Foreground microphone service with persistent notification and Stop action
- Repeated on-device speech recognition attempts only (no network-recognition fallback)
- Wake phrase: say “Hi Sabita” (also supports “Hey Sabita”, “Hey Saathi”, “हे साथी” and “हे सबिता”); the app replies “हाँ, बताइए? मैं सुन रही हूँ।” then listens for the command; or say both together, e.g. “Hey Saathi, open YouTube”.
- Strict allowlist commands: Phone Book/Dialer, Contacts, Gallery, Camera, Calendar, YouTube, Facebook, WhatsApp, Instagram and Google Chrome. Settings and Torch commands are not included.
- Hindi (India) speech recognition preference; offline Hindi speech model must be installed on the phone

## Build
1. Install Android Studio on a computer.
2. Extract this ZIP and open the `VoiceSaathiBackground` folder.
3. Install Android SDK 35 if prompted and allow Gradle sync.
4. Connect your Samsung phone, press Run, and grant microphone permission.
5. To create an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Offline/privacy behavior
- The app manifest does not request the INTERNET permission, so this app itself cannot open network sockets using the normal Android internet permission.
- On Android 12 (API 31) or newer, it uses `createOnDeviceSpeechRecognizer` and refuses to fall back to a potentially network-backed recognizer.
- You must have an offline Hindi speech-recognition model available in the phone’s speech/voice input settings. Availability varies by device and speech provider. If on-device recognition is unavailable, listening stops.
- Building through GitHub Actions still sends the source code to GitHub and uses the internet during the cloud build. To avoid uploading code to GitHub, build locally on a trusted computer instead.
- This is not a guarantee about the phone’s system speech provider or other apps; test offline by turning on Airplane mode after installing the offline language model.

## Important Android limitations
- Start listening while the app is visible; Android restricts starting microphone foreground services from the background.
- The persistent notification indicates microphone use and offers Stop.
- Android/Samsung may stop the service due to battery optimization or speech-service behavior.
- Android's SpeechRecognizer is not designed as a guaranteed always-on wake-word engine. This sample restarts recognition between phrases, so it may miss commands and consume battery. In this offline build, recognition does not intentionally use mobile data or Wi-Fi.
- It cannot listen through all lock-screen states or bypass security. Do not rely on it for emergencies.
- This sample is not yet built or tested on a physical device. Some manufacturers/Android versions may require adjustments.
- Torch control may need CAMERA permission; this starter currently asks for microphone permission only at start, so torch commands may require adding an explicit camera permission request before using torch.

## Phone-only build option (cloud build)

This project includes `.github/workflows/build-apk.yml` for a GitHub Actions cloud build. It has not been tested end-to-end; a build error may require code/configuration fixes.

1. On your phone, download and extract this ZIP.
2. Create a repository on GitHub in your browser.
3. Upload the extracted project files and folders to the repository root (do not upload only the ZIP). Keep `.github/workflows/build-apk.yml` at that exact path.
4. Open the repository's **Actions** tab and select **Build Voice Saathi APK**. If prompted, enable Actions, then tap **Run workflow**.
5. When the run finishes successfully, open that run and download the `VoiceSaathi-debug-apk` artifact. Extract it on your phone and tap the APK to install it.

GitHub's mobile upload interface may make uploading nested folders difficult. If so, a computer or help from someone who can upload the project is the easier route. Only download/install APKs you built or trust.


## Current allowlist and voice-identity status
- Command routing only handles the ten app categories approved by the user; it does not accept arbitrary package names. A launcher app may still expose links to other apps, and this app does not technically lock the whole phone to those ten apps.
- This starter does **not** yet perform speaker/voiceprint verification. The wake phrase can be spoken by another person, so do not treat wake-word detection as proof of identity. Reliable owner-only operation needs a separately implemented and tested speaker-verification step; sensitive actions should use Android authentication or an explicit confirmation.
- Phone Book currently opens the dialer; Contacts opens the contacts view. This build does not yet implement contact-name matching plus confirmation and then placing a call.
- No APK has been built or tested on the Samsung Galaxy A17 as part of this update.
